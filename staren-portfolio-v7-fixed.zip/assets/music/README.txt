Put your own licensed/owned MP3 files here: staren-01.mp3 through staren-06.mp3. The player works offline; browsers may require one tap before allowing sound.
