# STAREN Portfolio + CMS

This package keeps the existing V5 portfolio visual design and adds a separate admin content management system.

## What the CMS manages

- Site title, name, hero text and all profile/about copy
- Hero photo 1, secondary photo 2 and supporting photo 3
- Projects: title, slug, category, kicker, short/full descriptions, role, status, year, order, technologies, GitHub, live site, YouTube, Facebook, thumbnail, screenshots, videos and files
- Skills: name, category, level, note and order
- Hobbies/interests: name, description, image, link and order
- Experience: company, role, dates, description and link
- Social/public links
- Media uploads for images, videos, PDFs, ZIPs and text files (25 MB per file)

## Run locally

1. Install Node.js 18+.
2. Copy `.env.example` to `.env`.
3. Set `ADMIN_EMAIL`, `ADMIN_PASSWORD`, and a long random `SESSION_SECRET`.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000/admin/` for the dashboard.
7. Open `http://localhost:3000/` for the portfolio.

The content database is `data/content.json`. Uploaded media is stored in `uploads/`.

## Publishing

The app is intentionally a small Node/Express application so the portfolio and CMS can run from the same host. When deployed, the portfolio reads `/api/public/content`, while `/admin/` is the private editor.

For production, use a hosting provider that supports a persistent Node process and persistent disk storage. If the host has ephemeral storage, move the content/media storage to a database/object-storage service before launch.

## Important

The three existing photos are already included in `uploads/` in the requested priority order: `staren-01.png`, `staren-02.png`, `staren-03.png`.

The current visual layout is preserved. The CMS changes content, not the visual identity.
