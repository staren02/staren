const menuToggle = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');

menuToggle?.addEventListener('click', () => {
  const open = navLinks.classList.toggle('open');
  menuToggle.classList.toggle('active', open);
  menuToggle.setAttribute('aria-expanded', String(open));
});

document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
    menuToggle.classList.remove('active');
    menuToggle.setAttribute('aria-expanded', 'false');
  });
});

const revealTargets = document.querySelectorAll('.statement-content, .section-head, .project, .photo-copy, .secondary-photo, .about-layout, .lab-board, .process-list, .contact-main');
revealTargets.forEach(el => el.classList.add('reveal'));
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
revealTargets.forEach(el => observer.observe(el));

const modal = document.querySelector('.project-modal');
const modalTitle = document.querySelector('#modal-title');
const modalDescription = document.querySelector('#modal-description');
const modalGithub = document.querySelector('#modal-github');
const modalClose = document.querySelector('.modal-close');
const modalStatus = document.querySelector('#modal-status');
const modalType = document.querySelector('#modal-type');
const modalRole = document.querySelector('#modal-role');
const modalFocus = document.querySelector('#modal-focus');
const modalCopy = document.querySelector('#modal-copy');

const projectData = {
  'Pikup': {
    status: 'BUILDING', type: 'PRODUCT / DELIVERY', role: 'CONCEPT + DEVELOPMENT', focus: 'Local delivery systems',
    description: 'A local delivery platform concept connecting customers, merchants and riders. I started it from a real problem: delivery around Buea can be unreliable, especially when there is no backup when a rider is unavailable.',
    github: 'https://github.com/staren02'
  },
  'Auto Elite': {
    status: 'CLIENT PROJECT', type: 'WEB / VEHICLES', role: 'WEB DEVELOPMENT', focus: 'Browsing + inventory',
    description: 'A real-world vehicle dealership and rental website. The main goal was straightforward: make the vehicles easy to discover, understand and browse without turning the site into a complicated catalogue.',
    github: 'https://github.com/staren02/autoelite'
  },
  'Student Marketplace': {
    status: 'PERSONAL PROJECT', type: 'WEB / COMMUNITY', role: 'DESIGN + DEVELOPMENT', focus: 'Student buying + selling',
    description: 'A marketplace concept built around the everyday buying and selling needs of students. It was one of the projects that helped me think beyond individual pages and more about how people actually move through a product.',
    github: 'https://github.com/staren02'
  }
};

function openProject(name) {
  const data = projectData[name];
  if (!data) return;
  modalTitle.textContent = name;
  modalDescription.textContent = data.description;
  modalGithub.href = data.github;
  modalStatus.textContent = data.status;
  modalType.textContent = data.type;
  modalRole.textContent = data.role;
  modalFocus.textContent = data.focus;
  modal.dataset.project = name;
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
  document.body.classList.add('modal-open');
  modalClose?.focus();
}

document.querySelectorAll('.project').forEach(card => {
  const visual = card.querySelector('.project-visual');
  const button = card.querySelector('.project-open');
  const name = card.dataset.project;
  visual?.setAttribute('role', 'button');
  visual?.setAttribute('tabindex', '0');
  visual?.setAttribute('aria-label', `Open notes for ${name}`);
  visual?.addEventListener('click', () => openProject(name));
  visual?.addEventListener('keydown', event => {
    if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); openProject(name); }
  });
  button?.addEventListener('click', () => openProject(name));
});

function closeModal() {
  modal.classList.remove('open');
  modal.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('modal-open');
}
modalClose?.addEventListener('click', closeModal);
modal?.addEventListener('click', event => { if (event.target === modal) closeModal(); });
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeModal(); });

modalCopy?.addEventListener('click', async () => {
  const name = modal.dataset.project || 'project';
  const url = `${window.location.href.split('#')[0]}#work`;
  try {
    await navigator.clipboard.writeText(url);
    modalCopy.textContent = 'Copied';
    setTimeout(() => { modalCopy.textContent = 'Copy project link'; }, 1400);
  } catch {
    modalCopy.textContent = 'Link is #work';
    setTimeout(() => { modalCopy.textContent = 'Copy project link'; }, 1400);
  }
});

const sections = ['top', 'work', 'about', 'lab', 'process', 'contact'];
const navIndex = document.querySelector('.nav-index');
function updateNavIndex() {
  const y = window.scrollY + window.innerHeight * 0.35;
  let active = 0;
  sections.forEach((id, index) => {
    const section = document.getElementById(id);
    if (section && y >= section.offsetTop) active = index;
  });
  if (navIndex) navIndex.textContent = `${String(active).padStart(2, '0')} / 06`;
}
window.addEventListener('scroll', updateNavIndex, { passive: true });
updateNavIndex();

const cursorDot = document.createElement('div');
cursorDot.className = 'cursor-dot';
document.body.appendChild(cursorDot);
const cursorStyle = document.createElement('style');
cursorStyle.textContent = `
  @media (pointer: fine) {
    .cursor-dot { position: fixed; width: 7px; height: 7px; border-radius: 50%; background: var(--ink); pointer-events: none; z-index: 999; opacity: .65; transform: translate(-50%, -50%); transition: width .2s ease, height .2s ease, opacity .2s ease; }
    body:has(a:hover) .cursor-dot, body:has(button:hover) .cursor-dot { width: 13px; height: 13px; opacity: .35; }
  }
  @media (pointer: coarse) { .cursor-dot { display: none; } }
`;
document.head.appendChild(cursorStyle);
window.addEventListener('pointermove', event => {
  cursorDot.style.left = `${event.clientX}px`;
  cursorDot.style.top = `${event.clientY}px`;
}, { passive: true });

/* V5 interactions */
const progressBar = document.querySelector('.scroll-progress span');
function updateProgress() {
  const max = document.documentElement.scrollHeight - window.innerHeight;
  const ratio = max > 0 ? window.scrollY / max : 0;
  if (progressBar) progressBar.style.width = `${ratio * 100}%`;
}
window.addEventListener('scroll', updateProgress, { passive: true });
updateProgress();

// Small image parallax: subtle enough to preserve the editorial feel.
const portrait = document.querySelector('.portrait-frame img');
const secondary = document.querySelector('.secondary-photo img');
let parallaxTick = false;
function parallax() {
  if (parallaxTick) return;
  parallaxTick = true;
  requestAnimationFrame(() => {
    const y = window.scrollY;
    if (portrait && window.innerWidth > 900) portrait.style.transform = `scale(1.015) translateY(${Math.min(18, y * 0.012)}px)`;
    if (secondary && window.innerWidth > 900) secondary.style.transform = `translateY(${Math.max(-8, Math.min(8, (y - secondary.getBoundingClientRect().top) * 0.015))}px)`;
    parallaxTick = false;
  });
}
window.addEventListener('scroll', parallax, { passive:true });

// Public GitHub repositories, with a graceful fallback when offline.
const repoFeed = document.querySelector('#repo-feed');
async function loadRepos() {
  if (!repoFeed) return;
  try {
    const response = await fetch('https://api.github.com/users/staren02/repos?per_page=6&sort=updated', { headers: { Accept: 'application/vnd.github+json' } });
    if (!response.ok) throw new Error('GitHub request failed');
    const repos = await response.json();
    if (!Array.isArray(repos) || !repos.length) throw new Error('No repositories');
    repoFeed.innerHTML = repos.slice(0,4).map(repo => {
      const description = repo.description ? repo.description.replace(/</g,'&lt;').replace(/>/g,'&gt;') : 'Public repository — no description yet.';
      return `<article class="repo-card"><a href="${repo.html_url}" target="_blank" rel="noopener"><h3 class="repo-name">${repo.name}</h3><p class="repo-description">${description}</p><div class="repo-meta"><span>${repo.language || 'CODE'}</span><span>${repo.stargazers_count} ★</span><span>OPEN ↗</span></div></a></article>`;
    }).join('');
  } catch (error) {
    repoFeed.innerHTML = `<div class="repo-card"><a href="https://github.com/staren02" target="_blank" rel="noopener"><h3 class="repo-name">See the full repository list</h3><p class="repo-description">GitHub could not be reached from this visit. The work is still there.</p><div class="repo-meta"><span>GITHUB</span><span>STAREN02</span><span>OPEN ↗</span></div></a></div>`;
  }
}
loadRepos();

// Make the contact email easy to copy without adding another visible control.
const emailLink = document.querySelector('.contact-link');
emailLink?.addEventListener('contextmenu', async () => {
  try { await navigator.clipboard.writeText('staren906@gmail.com'); } catch (_) {}
});
