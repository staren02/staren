window.addEventListener('staren:content-ready', e => {
  const db=e.detail||{}; const projects=[...(db.projects||[])].sort((a,b)=>(a.order||99)-(b.order||99));
  // Rebuild the project list from CMS data so adding a fourth/fifth/etc. project works without code edits.
  const list=document.querySelector('.project-list');
  if(list&&projects.length){
    list.innerHTML=projects.map((p,i)=>{
      const cls=['project-pikup','project-auto','project-market'][i%3];
      const tech=(p.technologies||[]).slice(0,3).map(t=>`<span>${esc(t)}</span>`).join('');
      const visual=i%3===0?`<div class="visual-grid"></div><div class="visual-word">${esc(p.title.toUpperCase())}</div><div class="visual-orbit"></div>`:i%3===1?`<div class="auto-frame"><span>${esc((p.title.split(' ')[0]||'PROJECT').toUpperCase())}</span><strong>${esc(p.title.split(' ').slice(1).join(' ').toUpperCase()||'WORK')}</strong><small>${esc((p.category||'PROJECT').toUpperCase())}</small></div>`:`<div class="market-card"><span>${esc((p.title.split(' ')[0]||'PROJECT').toUpperCase())}</span><span>${esc(p.title.split(' ').slice(1).join(' ').toUpperCase()||'PROJECT')}</span><i></i></div>`;
      return `<article class="project ${cls}" data-project="${esc(p.title)}"><div class="project-number mono">${String(i+1).padStart(2,'0')}</div><div class="project-visual" role="button" tabindex="0" aria-label="Open notes for ${esc(p.title)}">${visual}<span class="visual-tag mono">${esc((p.category||'PROJECT').toUpperCase())}</span></div><div class="project-info"><div><span class="project-kicker mono">${esc(p.kicker||p.category||'PROJECT')}</span><h3>${esc(p.title)}</h3><p>${esc(p.shortDescription||p.description||'')}</p><div class="project-tags">${tech}</div></div><div class="project-footer"><span class="mono">${esc((p.status||'PROJECT').toUpperCase())}</span><button class="project-open" type="button">View notes <span>↗</span></button></div></div></article>`;
    }).join('');
    list.querySelectorAll('.project').forEach(card=>{const name=card.dataset.project;const v=card.querySelector('.project-visual');const b=card.querySelector('.project-open');v.addEventListener('click',()=>openProjectFromCMS(name));v.addEventListener('keydown',x=>{if(x.key==='Enter'||x.key===' '){x.preventDefault();openProjectFromCMS(name)}});b.addEventListener('click',()=>openProjectFromCMS(name));});
  }
  // Let the existing visual lab surface the current CMS-managed skills/interests without changing its design.
  const skills=[...(db.skills||[])].sort((a,b)=>(a.order||99)-(b.order||99)); const hobbies=[...(db.hobbies||[])].sort((a,b)=>(a.order||99)-(b.order||99));
  const notes=document.querySelectorAll('.lab-note'); const lab=[skills[0],skills[1],hobbies[0]].filter(Boolean);
  notes.forEach((n,i)=>{if(!lab[i])return;const x=lab[i];n.querySelector('strong').textContent=x.name;n.querySelector('p').textContent=x.note||x.description||'';});

  window.openProjectFromCMS=function(name){
    const p=projects.find(x=>x.title===name); if(!p)return;
    // projectData is declared by the existing portfolio script; update its entry so the existing modal stays intact.
    if(typeof projectData!=='undefined') projectData[name]={status:(p.status||'PROJECT').toUpperCase(),type:(p.category||'PROJECT').toUpperCase(),role:(p.role||'DEVELOPER').toUpperCase(),focus:(p.technologies||[]).slice(0,3).join(' · ')||'PROJECT',description:p.description||p.shortDescription||'',github:p.github||'https://github.com/staren02'};
    openProject(name);
    const modal=document.querySelector('.project-modal'); if(!modal)return;
    let media=modal.querySelector('.cms-modal-media'); if(media)media.remove();
    const urls=[...(p.screenshots||[])].filter(Boolean); const links=[['live','Live site'],['youtube','YouTube'],['facebook','Facebook'],['github','GitHub']].filter(([k])=>p[k]);
    const wrap=document.createElement('div');wrap.className='cms-modal-media';
    if(urls.length)wrap.innerHTML=`<div class="modal-media">${urls.map(u=>`<img src="${esc(u)}" alt="${esc(p.title)} screenshot" loading="lazy">`).join('')}</div>`;
    if(links.length)wrap.innerHTML+=`<div class="modal-links">${links.map(([k,l])=>`<a href="${esc(p[k])}" target="_blank" rel="noopener">${l} ↗</a>`).join('')}</div>`;
    const content=modal.querySelector('.modal-content'); const actions=modal.querySelector('.modal-actions'); if(content&&actions)content.insertBefore(wrap,actions);
  };
});
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
