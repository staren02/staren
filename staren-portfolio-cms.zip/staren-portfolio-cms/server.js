require('dotenv').config();
const express = require('express');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const DATA_FILE = path.join(DATA_DIR, 'content.json');
const UPLOAD_DIR = path.join(ROOT, 'uploads');
const ADMIN_DIR = path.join(ROOT, 'admin');
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

function readContent() { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); }
function writeContent(data) {
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, DATA_FILE);
}
function clean(value) { return typeof value === 'string' ? value.trim() : value; }
function id() { return crypto.randomBytes(8).toString('hex'); }

const email = process.env.ADMIN_EMAIL || 'admin@example.com';
const password = process.env.ADMIN_PASSWORD || 'change-this-password';
const secret = process.env.SESSION_SECRET || 'dev-only-change-me';
const passwordHash = bcrypt.hashSync(password, 12);

function makeToken() {
  const payload = Buffer.from(JSON.stringify({ email, exp: Date.now() + 1000 * 60 * 60 * 12 })).toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
  return payload + '.' + sig;
}
function validToken(token) {
  try {
    const [payload, sig] = String(token || '').split('.');
    if (!payload || !sig) return false;
    const expected = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return false;
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString());
    return data.email === email && data.exp > Date.now();
  } catch { return false; }
}
function auth(req, res, next) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, '') || req.cookies?.cms_token;
  if (!validToken(token)) return res.status(401).json({ error: 'Unauthorized' });
  next();
}

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '7d' }));
app.use(express.static(ROOT, { index: 'index.html', extensions: ['html'] }));

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const base = path.basename(file.originalname, ext).replace(/[^a-z0-9_-]+/gi, '-').slice(0, 60) || 'upload';
    cb(null, `${Date.now()}-${crypto.randomBytes(4).toString('hex')}-${base}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 25 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = /image\/(jpeg|png|webp|gif)|video\/(mp4|webm|quicktime)|application\/pdf|application\/zip|text\/plain/;
    cb(null, allowed.test(file.mimetype));
  }
});

app.post('/api/auth/login', (req, res) => {
  const user = clean(req.body.email);
  const pass = String(req.body.password || '');
  if (user !== email || !bcrypt.compareSync(pass, passwordHash)) return res.status(401).json({ error: 'Invalid email or password' });
  res.json({ token: makeToken(), email });
});

app.get('/api/public/content', (_req, res) => {
  const data = readContent();
  res.json(data);
});

app.get('/api/admin/content', auth, (_req, res) => res.json(readContent()));

const collections = ['projects', 'skills', 'hobbies', 'experience', 'socials'];
app.put('/api/admin/settings', auth, (req, res) => {
  const data = readContent();
  data.settings = { ...data.settings, ...req.body };
  writeContent(data);
  res.json(data.settings);
});

for (const collection of collections) {
  app.post(`/api/admin/${collection}`, auth, (req, res) => {
    const data = readContent();
    const item = { id: id(), ...req.body };
    data[collection].push(item);
    writeContent(data);
    res.status(201).json(item);
  });
  app.put(`/api/admin/${collection}/:id`, auth, (req, res) => {
    const data = readContent();
    const index = data[collection].findIndex(x => x.id === req.params.id);
    if (index < 0) return res.status(404).json({ error: 'Not found' });
    data[collection][index] = { ...data[collection][index], ...req.body, id: req.params.id };
    writeContent(data);
    res.json(data[collection][index]);
  });
  app.delete(`/api/admin/${collection}/:id`, auth, (req, res) => {
    const data = readContent();
    const before = data[collection].length;
    data[collection] = data[collection].filter(x => x.id !== req.params.id);
    if (data[collection].length === before) return res.status(404).json({ error: 'Not found' });
    writeContent(data);
    res.status(204).end();
  });
}

app.post('/api/admin/upload', auth, upload.array('files', 20), (req, res) => {
  res.json({ files: req.files.map(file => ({ name: file.originalname, url: `/uploads/${file.filename}`, type: file.mimetype, size: file.size })) });
});

app.get('/admin', (_req, res) => res.sendFile(path.join(ADMIN_DIR, 'index.html')));
app.get('/admin/', (_req, res) => res.sendFile(path.join(ADMIN_DIR, 'index.html')));

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(400).json({ error: err.message || 'Request failed' });
});

app.listen(PORT, () => console.log(`Staren portfolio + CMS running at http://localhost:${PORT}`));
