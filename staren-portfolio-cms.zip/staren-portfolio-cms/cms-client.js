/* Public portfolio content bridge. Visual structure stays the same; content comes from the CMS. */
(async function(){
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  try {
    const r=await fetch('/api/public/content',{cache:'no-store'}); if(!r.ok) return; const db=await r.json();
    const s=db.settings||{};
    document.title=s.siteTitle||document.title;
    const meta=document.querySelector('meta[name="description"]'); if(meta&&s.heroDescription)meta.content=s.heroDescription;
    const hero=document.querySelector('.hero');
    if(hero){
      const eyebrow=hero.querySelector('.eyebrow'); if(eyebrow) eyebrow.innerHTML=`${esc(s.heroEyebrow||s.name||'STAREN SOBA')} <span>↗</span>`;
      const h1=hero.querySelector('h1'); if(h1) h1.innerHTML=`${esc(s.heroTitleLine1||'I make')}<br><em>${esc((s.heroTitleLine2||'things.').replace(/^\s+|\s+$/g,''))}</em>`;
      const desc=hero.querySelector('.hero-description'); if(desc) desc.textContent=s.heroDescription||desc.textContent;
      const img=hero.querySelector('.portrait-frame img'); if(img&&s.heroImage){img.src=s.heroImage;img.alt=`${s.name||'Staren'} portrait`;}
      const loc=hero.querySelector('.hero-meta span:last-child'); if(loc) loc.textContent=s.location||loc.textContent;
    }
    const second=document.querySelector('.secondary-photo img'); if(second&&s.heroImage2)second.src=s.heroImage2;
    const third=document.querySelector('.about-photo img'); if(third&&s.heroImage3)third.src=s.heroImage3;
    const aboutLead=document.querySelector('.about-lead'); if(aboutLead&&s.aboutLead)aboutLead.textContent=s.aboutLead;
    const aboutPs=document.querySelectorAll('.about-copy p:not(.about-lead)'); if(aboutPs[0]&&s.aboutBody1)aboutPs[0].textContent=s.aboutBody1;if(aboutPs[1]&&s.aboutBody2)aboutPs[1].textContent=s.aboutBody2;
    const contact=document.querySelector('.contact-link'); if(contact&&s.email){contact.href=`mailto:${s.email}`;contact.innerHTML=`${esc(s.email)} <span>↗</span>`;}
    const socials=db.socials||[]; document.querySelectorAll('.contact-socials').forEach(box=>{box.innerHTML=socials.map(x=>`<a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(x.label)} ↗</a>`).join('');});
    const projects=[...(db.projects||[])].sort((a,b)=>(a.order||99)-(b.order||99));
    const cards=[...document.querySelectorAll('.project')];
    cards.forEach((card,i)=>{const p=projects[i];if(!p)return;card.dataset.project=p.title;card.querySelector('.project-kicker').textContent=p.kicker||p.category||'';card.querySelector('h3').textContent=p.title;card.querySelector('.project-info p').textContent=p.shortDescription||p.description||'';card.querySelector('.visual-tag').textContent=(p.category||'PROJECT').toUpperCase();card.querySelector('.project-footer > span').textContent=(p.status||'PROJECT').toUpperCase();const tags=card.querySelector('.project-tags');if(tags)tags.innerHTML=(p.technologies||[]).slice(0,3).map(t=>`<span>${esc(t)}</span>`).join('');});
    window.STAREN_CMS={db,projects};
    window.dispatchEvent(new CustomEvent('staren:content-ready',{detail:db}));
  } catch(e) { console.warn('CMS content unavailable; keeping static portfolio content.',e); }
})();
